import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

n_bin = 10
n_bin1 = 2**10

count = 100
count1 = 10**4
data = np.random.randint(0,n_bin, size=count)
data1 = np.random.randint(0,n_bin1, size=count1)
#data = np.random.rand(10**4)

fig, axes= plt.subplots(ncols=3, nrows=2, figsize=(12,6), tight_layout=True, sharey=False, sharex=False)

n, bins, patches = axes[0,0].hist(data, bins=n_bin)
axes[0,0].set_xlim(-1,10)
axes[0,0].set_ylim(0,20)
axes[0,0].set_xlabel(f'fig1, bins={n_bin}, count={count}')

axes[0,1].bar(bins[:-1], n)
axes[0,1].set_xlim(-1,10)
axes[0,1].set_ylim(0,20)
axes[0,1].set_xlabel(f'fig2, extract x and y values')

axes[0,2].set_xlim(-1,10)
axes[0,2].bar(bins[:-1], n/n)
axes[0,2].set_ylim(0,2)
axes[0,2].set_xlabel(f'fig3, normed')

n1, bins1, patches1 = axes[1,0].hist(data1, bins=n_bin1)
axes[1,0].grid(True)
axes[1,0].set_xlabel(f'fig4, bins={n_bin1}, count={count1}')
axes[1,0].set_ylim(0,20)

axes[1,1].bar(bins1[:-1], n1)
axes[1,1].set_ylim(0,20)
axes[1,1].set_xlabel(f'fig5, extract x and y values')

axes[1,2].bar(bins1[:-1], n1/n1)
axes[1,2].set_ylim(0,2)
axes[1,2].set_xlabel(f'fig6, normed')

fig.savefig('./test_hist.png', dpi=300)